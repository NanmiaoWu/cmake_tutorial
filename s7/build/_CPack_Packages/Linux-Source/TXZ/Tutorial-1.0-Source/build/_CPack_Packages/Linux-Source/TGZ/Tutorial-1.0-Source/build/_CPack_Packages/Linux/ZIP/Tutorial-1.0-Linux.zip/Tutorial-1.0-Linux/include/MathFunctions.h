
double mysqrt(double x);
